package com.airportworldclock;

import java.text.Normalizer;
import java.util.Locale;

/** Lightweight city entry; code is retained only for migrating old selections. */
final class City {
    final String code;
    final String chinese;
    final String english;
    final String zoneId;
    private final String searchable;

    City(String code, String chinese, String english, String zoneId) {
        this.code = code;
        this.chinese = chinese;
        this.english = english;
        this.zoneId = zoneId;
        this.searchable = normalize(chinese + " " + english);
    }

    boolean matches(String query) {
        return searchable.contains(normalize(query));
    }

    private static String normalize(String value) {
        String decomposed = Normalizer.normalize(value, Normalizer.Form.NFD);
        return decomposed.replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).trim();
    }
}
