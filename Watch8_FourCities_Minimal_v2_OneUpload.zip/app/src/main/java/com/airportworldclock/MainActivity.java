package com.airportworldclock;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Four-city Watch 8 clock. Two fixed cities, two directly searchable city slots. */
public final class MainActivity extends Activity {
    private static final int BLACK = Color.BLACK;
    private static final int GREEN = Color.rgb(76, 247, 110);
    private static final int SOFT_GREEN = Color.rgb(130, 213, 148);
    private static final int BORDER = Color.rgb(25, 74, 38);
    private static final String PREFS = "airport_world_clock_v1";
    private static final String[] WEEK = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"};
    private static final String BEIJING = "PEK";
    private static final String NEW_YORK = "JFK";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<ClockView> clocks = new ArrayList<>(4);
    private final String[] slots = {BEIJING, NEW_YORK, "EZE", "LHR"};
    private SharedPreferences prefs;
    private boolean onSearch;
    private boolean running;
    private int editingSlot = 2;
    private LinearLayout searchResults;
    private float downX, downY;
    private boolean trackingSwipe;

    private static final class ClockView {
        final City city;
        final TextView time;
        final TextView date;
        ClockView(City city, TextView time, TextView date) {
            this.city = city;
            this.time = time;
            this.date = date;
        }
    }

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!running || onSearch) return;
            refreshClocks();
            long delay = 60000L - Math.floorMod(System.currentTimeMillis(), 60000L) + 90L;
            handler.postDelayed(this, Math.max(delay, 1000L));
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(BLACK);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        restoreSlots();
        showHome();
    }

    @Override protected void onResume() {
        super.onResume();
        running = true;
        handler.removeCallbacks(ticker);
        if (!onSearch) handler.post(ticker);
    }

    @Override protected void onPause() {
        running = false;
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(ticker);
        super.onDestroy();
    }

    /** A quick right swipe is Back, and from the four-clock page it closes the app. */
    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getX();
                downY = event.getY();
                trackingSwipe = true;
                break;
            case MotionEvent.ACTION_UP:
                if (trackingSwipe) {
                    trackingSwipe = false;
                    float dx = event.getX() - downX;
                    float dy = event.getY() - downY;
                    if (dx > dp(55) && Math.abs(dy) < dx * .55f &&
                            downX < getResources().getDisplayMetrics().widthPixels * .37f) {
                        MotionEvent cancel = MotionEvent.obtain(event);
                        cancel.setAction(MotionEvent.ACTION_CANCEL);
                        super.dispatchTouchEvent(cancel);
                        cancel.recycle();
                        navigateBack();
                        return true;
                    }
                }
                break;
            case MotionEvent.ACTION_CANCEL:
                trackingSwipe = false;
                break;
            default:
                break;
        }
        return super.dispatchTouchEvent(event);
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() {
        navigateBack();
    }

    private void navigateBack() {
        if (onSearch) showHome();
        else returnToWatchHome();
    }

    private void returnToWatchHome() {
        // Home is handled by Wear OS / the watch launcher, not by a background service.
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(home);
        } catch (android.content.ActivityNotFoundException ignored) {
            // If a device exposes no HOME handler, closing this Activity still works.
        }
        finish();
        overridePendingTransition(0, 0);
    }

    private void restoreSlots() {
        String saved = prefs.getString("compact_slots", "");
        if (saved.isEmpty()) saved = prefs.getString("home_slots", "");
        // The old six-city version is migrated without overwriting user preferences.
        if (saved.isEmpty()) saved = "EZE,JFK,LHR,CDG,DXB,DOH";
        ArrayList<String> selected = new ArrayList<>(2);
        for (String part : saved.split(",")) {
            String code = part.trim();
            if (!code.equals(BEIJING) && !code.equals(NEW_YORK) &&
                    CityData.BY_CODE.containsKey(code) && !selected.contains(code)) selected.add(code);
            if (selected.size() == 2) break;
        }
        for (String fallback : new String[] {"EZE", "LHR", "HND", "SYD"}) {
            if (selected.size() >= 2) break;
            if (!selected.contains(fallback)) selected.add(fallback);
        }
        slots[2] = selected.get(0);
        slots[3] = selected.get(1);
    }

    private void replaceCity(int slot, City city) {
        if (slot < 2 || slot > 3 || city.code.equals(BEIJING) || city.code.equals(NEW_YORK)) return;
        int other = slot == 2 ? 3 : 2;
        if (city.code.equals(slots[other])) slots[other] = slots[slot];
        slots[slot] = city.code;
        prefs.edit().putString("compact_slots", slots[2] + "," + slots[3]).apply();
        showHome();
    }

    private void showHome() {
        onSearch = false;
        searchResults = null;
        clocks.clear();
        handler.removeCallbacks(ticker);

        boolean round = getResources().getConfiguration().isScreenRound();
        float heightDp = getResources().getDisplayMetrics().heightPixels /
                getResources().getDisplayMetrics().density;
        boolean compact = heightDp < 210;

        LinearLayout root = vertical();
        root.setBackgroundColor(BLACK);
        root.setPadding(dp(round ? 12 : 6), dp(round ? 23 : 6),
                dp(round ? 12 : 6), dp(round ? 23 : 6));
        setContentView(root);

        for (int r = 0; r < 2; r++) {
            LinearLayout pair = new LinearLayout(this);
            pair.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, 0, 1f);
            if (r == 0) rowParams.bottomMargin = dp(3);
            else rowParams.topMargin = dp(3);
            root.addView(pair, rowParams);
            for (int col = 0; col < 2; col++) {
                int slot = r * 2 + col;
                LinearLayout.LayoutParams cellParams = new LinearLayout.LayoutParams(0, -1, 1f);
                if (col == 0) cellParams.rightMargin = dp(3);
                else cellParams.leftMargin = dp(3);
                pair.addView(clockCard(CityData.BY_CODE.get(slots[slot]), slot, compact), cellParams);
            }
        }
        refreshClocks();
        if (running) handler.post(ticker);
    }

    private View clockCard(City city, int slot, boolean compact) {
        LinearLayout card = vertical();
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(2), dp(5), dp(2), dp(4));
        GradientDrawable background = new GradientDrawable();
        background.setColor(BLACK);
        background.setCornerRadius(dp(16));
        background.setStroke(dp(1), BORDER);
        card.setBackground(background);

        TextView name = txt(city.chinese, compact ? 16 : 19, GREEN, true);
        name.setSingleLine(true);
        name.setAutoSizeTextTypeUniformWithConfiguration(10, compact ? 16 : 19,
                1, TypedValue.COMPLEX_UNIT_SP);
        card.addView(name, new LinearLayout.LayoutParams(-1, 0, .9f));

        TextView time = txt("--:--", compact ? 29 : 34, GREEN, true);
        time.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        time.setFontFeatureSettings("tnum");
        time.setSingleLine(true);
        time.setAutoSizeTextTypeUniformWithConfiguration(22, compact ? 29 : 34,
                1, TypedValue.COMPLEX_UNIT_SP);
        card.addView(time, new LinearLayout.LayoutParams(-1, 0, 1.6f));

        TextView date = txt("--/-- 周一", compact ? 10 : 12, SOFT_GREEN, false);
        date.setSingleLine(true);
        date.setAutoSizeTextTypeUniformWithConfiguration(9, compact ? 10 : 12,
                1, TypedValue.COMPLEX_UNIT_SP);
        card.addView(date, new LinearLayout.LayoutParams(-1, 0, .9f));
        clocks.add(new ClockView(city, time, date));

        if (slot >= 2) {
            card.setContentDescription(city.chinese + "时间，点击搜索更换城市");
            card.setOnClickListener(v -> openSearch(slot));
        } else {
            card.setContentDescription(city.chinese + "固定时间");
            card.setClickable(false);
        }
        return card;
    }

    private void refreshClocks() {
        Instant instant = Instant.ofEpochMilli(System.currentTimeMillis());
        for (ClockView clock : clocks) {
            ZonedDateTime now = instant.atZone(ZoneId.of(clock.city.zoneId));
            clock.time.setText(String.format(Locale.US, "%02d:%02d", now.getHour(), now.getMinute()));
            clock.date.setText(String.format(Locale.US, "%02d/%02d", now.getMonthValue(), now.getDayOfMonth()) +
                    " " + WEEK[now.getDayOfWeek().getValue() - 1]);
        }
    }

    private void openSearch(int slot) {
        editingSlot = slot;
        onSearch = true;
        clocks.clear();
        handler.removeCallbacks(ticker);

        LinearLayout root = vertical();
        root.setPadding(dp(20), dp(22), dp(20), dp(12));
        root.setBackgroundColor(BLACK);
        setContentView(root);

        TextView back = txt("‹  返回    搜索第 " + (slot + 1) + " 城", 17, GREEN, true);
        back.setGravity(Gravity.CENTER);
        root.addView(back, new LinearLayout.LayoutParams(-1, dp(39)));
        back.setOnClickListener(v -> showHome());

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(17);
        input.setTextColor(GREEN);
        input.setHintTextColor(SOFT_GREEN);
        input.setHint("输入城市名称");
        input.setSelectAllOnFocus(false);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setImeOptions(EditorInfo.IME_ACTION_DONE);
        input.setPadding(dp(10), 0, dp(10), 0);
        GradientDrawable field = new GradientDrawable();
        field.setColor(Color.rgb(9, 29, 14));
        field.setStroke(dp(1), BORDER);
        field.setCornerRadius(dp(12));
        input.setBackground(field);
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(-1, dp(48));
        inputParams.topMargin = dp(4);
        root.addView(input, inputParams);

        ScrollView resultsScroll = new ScrollView(this);
        resultsScroll.setVerticalScrollBarEnabled(false);
        resultsScroll.setFillViewport(false);
        LinearLayout.LayoutParams scrollParams = new LinearLayout.LayoutParams(-1, 0, 1f);
        scrollParams.topMargin = dp(7);
        root.addView(resultsScroll, scrollParams);
        searchResults = vertical();
        resultsScroll.addView(searchResults);
        renderResults("");

        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int c, int a) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderResults(s.toString());
                resultsScroll.scrollTo(0, 0);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        input.requestFocus();
        input.post(() -> {
            if (!onSearch || isFinishing()) return;
            InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (keyboard != null) keyboard.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        });
        input.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (keyboard != null) keyboard.hideSoftInputFromWindow(input.getWindowToken(), 0);
                input.clearFocus();
                return true;
            }
            return false;
        });
    }

    private void renderResults(String query) {
        if (!onSearch || searchResults == null) return;
        searchResults.removeAllViews();
        if (TextUtils.isEmpty(query.trim())) {
            TextView hint = txt("搜索中文或英文城市名称", 12, SOFT_GREEN, false);
            searchResults.addView(hint, new LinearLayout.LayoutParams(-1, dp(54)));
            return;
        }
        int found = 0;
        List<City> cities = CityData.ALL;
        for (City city : cities) {
            if (city.code.equals(BEIJING) || city.code.equals(NEW_YORK) || !city.matches(query)) continue;
            LinearLayout result = vertical();
            result.setGravity(Gravity.CENTER);
            result.setPadding(dp(3), dp(4), dp(3), dp(4));
            TextView chinese = txt(city.chinese, 17, GREEN, true);
            TextView english = txt(city.english, 11, SOFT_GREEN, false);
            result.addView(chinese, new LinearLayout.LayoutParams(-1, dp(27)));
            result.addView(english, new LinearLayout.LayoutParams(-1, dp(19)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(57));
            lp.bottomMargin = dp(3);
            searchResults.addView(result, lp);
            result.setBackgroundColor(Color.rgb(10, 31, 16));
            result.setOnClickListener(v -> replaceCity(editingSlot, city));
            found++;
            if (found >= 40) break;
        }
        if (found == 0) {
            TextView nothing = txt("没有找到城市", 13, SOFT_GREEN, false);
            searchResults.addView(nothing, new LinearLayout.LayoutParams(-1, dp(55)));
        }
    }

    private TextView txt(String value, float sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER);
        view.setIncludeFontPadding(false);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private LinearLayout vertical() {
        LinearLayout view = new LinearLayout(this);
        view.setOrientation(LinearLayout.VERTICAL);
        return view;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
