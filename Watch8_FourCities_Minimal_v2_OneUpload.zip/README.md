# Watch 8 四城市世界时间 · 极简版 v2.0

- **固定第一排**：北京、纽约，不能更换，也不会弹出详情。
- **第二排两城**：点击任意下面的城市，直接进入**搜索城市**；选择结果后立即返回四城主页，不弹其他选项。
- **主页面**：四个时钟均为大号绿色文字，城市名 → 大号 `HH:mm` 时间 → 小号 `MM/dd 周几`，2×2 占满屏幕，黑色背景。
- **返回**：搜索页点击“返回”或从左侧向右滑动返回四城；主页从左侧向右滑动或系统返回键会请求打开系统表盘/主页面，手表实体 Home 键仍由系统控制。
- **时区**：使用系统 `java.time` / IANA 时区，自动计算夏令时；每分钟刷新一次，退到后台暂停刷新。不需要联网权限，也不需要后台服务。
- **城市目录**：沿用原版 134 个城市名称和时区，移除机场代码/机场选择/收藏/管理/详情/网络校时等页面。
- **已选城市**：自动尝试迁移旧版 `home_slots` 中最先出现的两个非北京/纽约城市；后续保存在 `compact_slots`，不会修改旧版已保存的 6 城选项。
- **安装包名**：保持 `com.airportworldclock.watch`；版本号升级到 `4`。

## GitHub 自动编译（只上传这个 ZIP 也可以）

1. 新建 GitHub 仓库，例如 `Watch8-FourCities-Minimal`。
2. 上传本 ZIP 文件到仓库根目录。**原有 workflow 放在 ZIP 里，GitHub 不会自动读取 ZIP 内的 workflow**。新仓库需要**先在电脑或手机解压 ZIP**，再使用 GitHub `Add file > Upload files` 上传解压后的项目文件（包括 `.github` 工作流）。如果你是在已经配置好解压并构建源码 ZIP 的旧仓库中，只上传 ZIP 即可。
3. 在仓库 **Actions** 中运行 `构建 Watch8 四城市极简世界时间 APK`。
4. 构建成功后，在 Artifacts 下载 `Watch8-FourCities-Minimal-APK`，解压获得 `app-debug.apk`。

也可以本地 Android SDK 35 + Java 17 + Gradle 8.11.1 编译：

```bash
gradle --no-daemon :app:assembleDebug
```

本工程沿用原工程的 Application ID，不保证与此前 APK 的签名证书一致。如果提示签名不一致，则需要使用同一签名证书重新签名或卸载旧版后安装；卸载前注意备份已选城市。
